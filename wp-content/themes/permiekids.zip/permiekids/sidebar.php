<?php if ( !function_exists('dynamic_sidebar') || !dynamic_sidebar() ) : ?>
	<?php dynamic_sidebar( 'Inner Pages Sidebar' ); ?>
<?php endif; ?>